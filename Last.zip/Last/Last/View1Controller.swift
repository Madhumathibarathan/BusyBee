//
//  View1Controller.swift
//  Last
//
//  Created by exam1001 on 24/05/18.
//  Copyright © 2018 exam1001. All rights reserved.
//

import UIKit

class View1Controller: UIViewController {

    @IBOutlet var label: UILabel!
    
    @IBAction func next(_ sender: Any) {
        if label.text=="January"
        {
            label.text="February"
            
        }
        else if label.text=="February"
        {
            label.text="March"
            
        }
        else if label.text=="March"
        {
            label.text="April"
        }
        else if label.text=="April"
        {
            label.text="May"
        }
        else if label.text=="May"
        {
            label.text="June"
        }
        else if label.text=="June"
        {
            label.text="July"
        }
        else if label.text=="July"
        {
            label.text="August"
        }
        else if label.text=="August"
        {
            label.text="September"
        }
        else if label.text=="September"
        {
            label.text="October"
        }
        else if label.text=="October"
        {
            label.text="November"
        }
        else if label.text=="November"
        {
            label.text="December"
        }
        
    }
    
    @IBAction func prev(_ sender: Any) {
        
        if label.text=="December"
        {
            label.text="November"
        }
        else if label.text=="November"
        {
            label.text="October"
        }
        else if label.text=="October"
        {
            label.text="September"
        }
        else if label.text=="September"
        {
            label.text="August"
        }
        else if label.text=="August"
        {
            label.text="July"
        }
        else if label.text=="July"
        {
            label.text="June"
        }
        else if label.text=="June"
        {
            label.text="May"
        }
        else if label.text=="May"
        {
            label.text="April"
        }
            
        else if label.text=="April"
        {
            label.text="March"
        }
        else if label.text=="March"
        {
            label.text="February"
        }
        else if label.text=="February"
        {
            label.text="January"
        }
        
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
